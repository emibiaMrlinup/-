package com.example.emibia.myapplication;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private WebSettings webSettings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView = (WebView) findViewById(R.id.webView);

//        String url = "http://192.168.15.103:8080/webview/alert.html";
//        String url = "http://192.168.15.103:8080/webview/confrim.html"
String url = "http://10.0.2.2:8080/";

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("Alert警示框")
                        .setMessage(message)
                        .setPositiveButton("确定", null)
                        .show();
                result.confirm(); //点击确定，对话框关闭
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                builder.setTitle("confirm确认信息")
                        .setMessage(message)
                        .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                result.confirm();
                            }
                        })
                        .setNeutralButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                result.cancel();
                            }
                        })
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, final JsPromptResult result) {
                final Dialog dialog = new Dialog(MainActivity.this);
                dialog.setContentView(R.layout.promptdialog);
                dialog.setTitle("prompt输入信息");
                //TextView tv = (TextView) findViewById(R.id.tv);
               // final EditText et = (EditText) findViewById(R.id.et);
              //  Button ok = (Button) dialog.findViewById(R.id.ok);
              //  Button cancel = (Button) dialog.findViewById(R.id.cancel);
                //tv.setText(message);
               // et.setText(defaultValue);
               /* ok.setOnClickListener(new View.OnClickListener() {//确定
                    @Override
                    public void onClick(View view) {
                        result.confirm(et.getText().toString());//将ediText里的值传递过去
                        dialog.cancel();
                    }
                });
                cancel.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        result.cancel();
                        dialog.cancel();
                    }
                });*/

                dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
                    @Override
                    public boolean onKey(DialogInterface dialogInterface, int keyCode, KeyEvent keyEvent) {
                        if (keyCode == KeyEvent.KEYCODE_BACK) {
                            result.cancel();
                            dialog.cancel();
                            return true;
                        }
                        return false;
                    }
                });
                dialog.show();
                return true;
            }
        });

        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return false;
            }
        });

        webView.loadUrl(url);
        webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true); //支持js
        webSettings.setUseWideViewPort(true); //自适应屏幕 任意比例缩放
        webSettings.setUseWideViewPort(true); //设置视图是否加载概览模式的网页 目的是一个屏幕可以显示这一页所有的内容
        webSettings.setBuiltInZoomControls(true); //显示缩放比例按钮
        webSettings.setSupportZoom(true); //使页面支持缩放
        webSettings.setCacheMode(WebSettings.LOAD_NO_CACHE); //不使用缓存 可以方便修改软件中错误的问题
    }
}